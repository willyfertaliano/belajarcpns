package com.belajarcpns.app

import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

data class Question(
    val category: String,
    val text: String,
    val options: List<String>,
    val answer: Int,
    val explanation: String
)

class QuizActivity : AppCompatActivity() {
    private lateinit var questions: List<Question>
    private var index = 0
    private var correct = 0
    private var answered = false
    private var points = 0

    private lateinit var tvTitle: TextView
    private lateinit var tvNumber: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvQuestion: TextView
    private lateinit var radioGroup: RadioGroup
    private lateinit var explanation: TextView
    private lateinit var next: Button
    private lateinit var radios: List<RadioButton>
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        tvTitle = findViewById(R.id.tvQuizTitle)
        tvNumber = findViewById(R.id.tvNumber)
        tvTimer = findViewById(R.id.tvTimer)
        tvQuestion = findViewById(R.id.tvQuestion)
        radioGroup = findViewById(R.id.radioGroup)
        explanation = findViewById(R.id.tvExplanation)
        next = findViewById(R.id.btnNext)
        radios = listOf(
            findViewById(R.id.radioA), findViewById(R.id.radioB),
            findViewById(R.id.radioC), findViewById(R.id.radioD),
            findViewById(R.id.radioE)
        )

        val category = intent.getStringExtra("category") ?: "Campuran"
        val bank = questionBank()
        questions = when (category) {
            "TWK" -> bank.filter { it.category == "TWK" }.shuffled().take(25)
            "TIU" -> bank.filter { it.category == "TIU" }.shuffled().take(25)
            "TKP" -> bank.filter { it.category == "TKP" }.shuffled().take(25)
            else -> bank.shuffled().take(100)
        }

        tvTitle.text = "Simulasi $category"
        startTimer(if (questions.size >= 100) 100L * 60_000L else questions.size * 60_000L)
        showQuestion()
        next.setOnClickListener { handleNext() }
    }

    private fun startTimer(ms: Long) {
        timer?.cancel()
        timer = object : CountDownTimer(ms, 1000) {
            override fun onTick(left: Long) {
                val total = left / 1000
                tvTimer.text = String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
            }
            override fun onFinish() {
                tvTimer.text = "00:00"
                finishQuiz(true)
            }
        }.start()
    }

    private fun showQuestion() {
        answered = false
        explanation.visibility = View.GONE
        radioGroup.clearCheck()
        next.text = "Jawab & Lanjut"
        val q = questions[index]
        tvNumber.text = "${index + 1}/${questions.size}"
        tvQuestion.text = q.text
        radios.forEachIndexed { i, radio -> radio.text = q.options[i] }
    }

    private fun handleNext() {
        if (!answered) {
            val checked = radioGroup.checkedRadioButtonId
            if (checked == -1) {
                Toast.makeText(this, "Pilih jawaban terlebih dahulu.", Toast.LENGTH_SHORT).show()
                return
            }
            val selected = radios.indexOfFirst { it.id == checked }
            val q = questions[index]
            if (selected == q.answer) {
                correct++
                points += if (q.category == "TKP") 5 else 5
                explanation.text = "✓ Jawaban tepat!\n\n${q.explanation}"
            } else {
                explanation.text = "✗ Jawaban belum tepat.\n\nJawaban benar: ${q.options[q.answer]}\n\n${q.explanation}"
            }
            explanation.visibility = View.VISIBLE
            answered = true
            next.text = if (index == questions.lastIndex) "Lihat Hasil" else "Soal Berikutnya"
        } else {
            if (index < questions.lastIndex) {
                index++
                showQuestion()
            } else {
                finishQuiz(false)
            }
        }
    }

    private fun finishQuiz(timeUp: Boolean) {
        timer?.cancel()
        val total = questions.size
        val score = ((correct.toDouble() / total) * 100).toInt()
        val message = buildString {
            append(if (timeUp) "⏰ Waktu habis!\n\n" else "")
            append("Benar: $correct dari $total soal\n")
            append("Nilai latihan: $score/100\n")
            append("Poin: $points\n\n")
            append(
                when {
                    score >= 80 -> "🔥 Sangat bagus! Pertahankan."
                    score >= 60 -> "👍 Lumayan. Tingkatkan latihan."
                    else -> "💪 Jangan menyerah. Pelajari pembahasan dan ulangi."
                }
            )
        }
        AlertDialog.Builder(this)
            .setTitle("Hasil Simulasi")
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("Kembali") { _, _ -> finish() }
            .show()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }

    private fun questionBank(): List<Question> {
        val list = mutableListOf<Question>()

        // 100 soal: 34 TWK, 33 TIU, 33 TKP.
        // Soal dibuat sebagai latihan contoh dan bukan salinan soal resmi.
        for (i in 1..34) {
            val q = when (i) {
                1 -> Question("TWK","Dasar negara Indonesia adalah...", listOf("Pancasila","UUD 1945","NKRI","Proklamasi","Bhinneka Tunggal Ika"),0,"Pancasila merupakan dasar negara Indonesia.")
                2 -> Question("TWK","Semboyan Bhinneka Tunggal Ika menekankan...", listOf("Persatuan dalam keberagaman","Keseragaman budaya","Kebebasan tanpa aturan","Persaingan antardaerah","Pemisahan kelompok"),0,"Maknanya adalah berbeda-beda tetapi tetap satu.")
                3 -> Question("TWK","Bentuk negara Indonesia adalah...", listOf("Kesatuan","Federasi","Konfederasi","Monarki","Serikat"),0,"Indonesia adalah negara kesatuan yang berbentuk republik.")
                4 -> Question("TWK","Lembaga yang berwenang mengubah dan menetapkan UUD adalah...", listOf("DPR","MPR","MA","MK","Presiden"),1,"Kewenangan tersebut dimiliki MPR.")
                5 -> Question("TWK","Sila ketiga Pancasila berbunyi...", listOf("Keadilan sosial bagi seluruh rakyat Indonesia","Persatuan Indonesia","Kemanusiaan yang adil dan beradab","Ketuhanan Yang Maha Esa","Kerakyatan yang dipimpin oleh hikmat kebijaksanaan"),1,"Sila ketiga adalah Persatuan Indonesia.")
                6 -> Question("TWK","Contoh sikap bela negara di lingkungan sekolah adalah...", listOf("Mengikuti aturan dan menjaga persatuan","Menolak upacara","Menyebarkan konflik","Merusak fasilitas","Menghindari kerja sama"),0,"Bela negara dapat diwujudkan melalui disiplin, tanggung jawab, dan menjaga persatuan.")
                7 -> Question("TWK","UUD 1945 merupakan...", listOf("Hukum dasar tertulis","Peraturan daerah","Keputusan presiden","Undang-undang biasa","Peraturan menteri"),0,"UUD 1945 merupakan hukum dasar tertulis Indonesia.")
                8 -> Question("TWK","Proklamasi Kemerdekaan Indonesia terjadi pada...", listOf("17 Agustus 1945","1 Juni 1945","18 Agustus 1945","20 Mei 1908","28 Oktober 1928"),0,"Proklamasi dibacakan pada 17 Agustus 1945.")
                9 -> Question("TWK","Musyawarah dalam demokrasi bertujuan untuk...", listOf("Mencapai keputusan bersama","Memenangkan kelompok sendiri","Menghindari tanggung jawab","Memaksakan kehendak","Menghapus perbedaan"),0,"Musyawarah diarahkan pada keputusan bersama yang dapat dipertanggungjawabkan.")
                10 -> Question("TWK","Sikap terhadap keberagaman suku dan budaya sebaiknya...", listOf("Menghargai","Menghina","Menghapus","Membatasi","Mengucilkan"),0,"Menghargai keberagaman memperkuat persatuan.")
                11 -> Question("TWK","NKRI merupakan singkatan dari...", listOf("Negara Kesatuan Republik Indonesia","Negara Kebangsaan Republik Indonesia","Negeri Kesatuan Republik Indonesia","Negara Kerajaan Republik Indonesia","Negara Kesatuan Rakyat Indonesia"),0,"NKRI berarti Negara Kesatuan Republik Indonesia.")
                12 -> Question("TWK","Sila pertama Pancasila adalah...", listOf("Ketuhanan Yang Maha Esa","Persatuan Indonesia","Keadilan sosial","Kemanusiaan yang adil dan beradab","Kerakyatan"),0,"Sila pertama adalah Ketuhanan Yang Maha Esa.")
                13 -> Question("TWK","Gotong royong mencerminkan nilai...", listOf("Kerja sama","Individualisme","Persaingan","Egoisme","Diskriminasi"),0,"Gotong royong merupakan bentuk kerja sama.")
                14 -> Question("TWK","Menghormati hukum merupakan contoh...", listOf("Kepatuhan terhadap aturan","Pelanggaran","Diskriminasi","Konflik","Apatisme"),0,"Warga negara perlu menaati hukum yang berlaku.")
                15 -> Question("TWK","Bahasa Indonesia berkedudukan sebagai bahasa...", listOf("Nasional dan negara","Daerah saja","Internasional saja","Keluarga","Asing"),0,"Bahasa Indonesia berfungsi sebagai bahasa nasional dan bahasa negara.")
                16 -> Question("TWK","Hari Kebangkitan Nasional diperingati setiap...", listOf("20 Mei","28 Oktober","17 Agustus","10 November","1 Juni"),0,"Hari Kebangkitan Nasional diperingati 20 Mei.")
                17 -> Question("TWK","Sumpah Pemuda terjadi pada...", listOf("28 Oktober 1928","20 Mei 1908","17 Agustus 1945","1 Juni 1945","10 November 1945"),0,"Kongres Pemuda II menghasilkan ikrar Sumpah Pemuda pada 28 Oktober 1928.")
                18 -> Question("TWK","Keadilan sosial merupakan sila ke...", listOf("Kelima","Pertama","Kedua","Ketiga","Keempat"),0,"Keadilan sosial bagi seluruh rakyat Indonesia adalah sila kelima.")
                19 -> Question("TWK","Lambang negara Indonesia adalah...", listOf("Garuda Pancasila","Burung Merpati","Harimau","Rajawali Nusantara","Garuda Nusantara"),0,"Lambang negara Indonesia adalah Garuda Pancasila.")
                20 -> Question("TWK","Sikap yang tepat terhadap keputusan hasil musyawarah adalah...", listOf("Melaksanakan dengan tanggung jawab","Menolak selalu","Menyebarkan konflik","Mengabaikan","Menghambat"),0,"Hasil musyawarah perlu dilaksanakan dengan tanggung jawab.")
                21 -> Question("TWK","Persatuan Indonesia paling tepat diwujudkan dengan...", listOf("Mengutamakan kepentingan bersama","Memaksakan kelompok","Menghindari perbedaan","Membeda-bedakan","Mementingkan diri"),0,"Kepentingan bersama membantu menjaga persatuan.")
                22 -> Question("TWK","Integritas berarti...", listOf("Konsisten antara nilai, ucapan, dan tindakan","Mencari keuntungan","Menghindari aturan","Menyembunyikan kesalahan","Mengikuti tekanan"),0,"Integritas berkaitan dengan kejujuran dan konsistensi moral.")
                23 -> Question("TWK","Contoh nasionalisme yang sehat adalah...", listOf("Menjaga persatuan dan menaati hukum","Merendahkan bangsa lain","Menolak budaya asing seluruhnya","Menyebarkan kebencian","Mengutamakan konflik"),0,"Nasionalisme dapat diwujudkan dengan kontribusi positif dan menghormati bangsa lain.")
                24 -> Question("TWK","Hak dan kewajiban warga negara harus...", listOf("Dilaksanakan secara seimbang","Dipisahkan total","Diabaikan","Dipaksakan","Dihapus"),0,"Hak dan kewajiban berjalan bersama.")
                25 -> Question("TWK","Contoh toleransi adalah...", listOf("Menghormati orang yang berbeda keyakinan","Memaksa keyakinan","Menghina","Mengucilkan","Melarang ibadah"),0,"Toleransi berarti menghormati perbedaan.")
                26 -> Question("TWK","Pancasila sebagai pandangan hidup berarti...", listOf("Menjadi pedoman dalam kehidupan","Hanya simbol","Hanya untuk upacara","Tidak boleh diterapkan","Sekadar hafalan"),0,"Pancasila menjadi pedoman nilai dalam kehidupan bermasyarakat.")
                27 -> Question("TWK","Sikap anti-korupsi yang tepat adalah...", listOf("Jujur dan menolak penyalahgunaan wewenang","Menerima hadiah terkait jabatan","Memanipulasi data","Menutup-nutupi","Mengutamakan keluarga"),0,"Kejujuran dan penolakan penyalahgunaan wewenang merupakan perilaku antikorupsi.")
                28 -> Question("TWK","Pelayanan publik yang baik harus...", listOf("Adil dan sesuai prosedur","Mendahulukan teman","Membeda-bedakan","Tidak transparan","Lambat"),0,"Pelayanan publik perlu adil, transparan, dan sesuai ketentuan.")
                29 -> Question("TWK","Kepentingan umum sebaiknya...", listOf("Didahulukan dalam pelayanan publik","Diabaikan","Dikalahkan oleh kepentingan pribadi","Dibatasi untuk kelompok tertentu","Dijadikan keuntungan pribadi"),0,"Pelayanan publik berorientasi pada kepentingan masyarakat.")
                30 -> Question("TWK","Sikap terhadap hoaks adalah...", listOf("Memeriksa kebenaran sebelum menyebarkan","Langsung menyebarkan","Menambah cerita","Menghapus sumber","Mempercayai semua"),0,"Informasi perlu diverifikasi sebelum dibagikan.")
                31 -> Question("TWK","Demokrasi mengutamakan...", listOf("Partisipasi dan kedaulatan rakyat","Kekuasaan mutlak","Paksaan","Diskriminasi","Ketertutupan"),0,"Demokrasi menempatkan rakyat sebagai pemegang kedaulatan.")
                32 -> Question("TWK","Semangat persatuan penting terutama untuk...", listOf("Menjaga keutuhan bangsa","Meningkatkan konflik","Memisahkan daerah","Membatasi kerja sama","Menghapus budaya"),0,"Persatuan membantu menjaga keutuhan NKRI.")
                33 -> Question("TWK","Contoh tanggung jawab sebagai warga negara adalah...", listOf("Menaati hukum","Menghindari pajak","Merusak fasilitas","Menyebar kebencian","Melanggar aturan"),0,"Menaati hukum adalah salah satu bentuk tanggung jawab warga negara.")
                34 -> Question("TWK","Kebebasan berpendapat harus disertai...", listOf("Tanggung jawab dan menghormati hak orang lain","Paksaan","Fitnah","Ancaman","Kebencian"),0,"Kebebasan berpendapat tetap memiliki batas hukum dan tanggung jawab.")
                else -> error("")
            }
            list.add(q)
        }

        val tiuTemplates = listOf(
            Triple("Jika 3x + 7 = 22, nilai x adalah...", listOf("3","4","5","6","7"), 2),
            Triple("25% dari 240 adalah...", listOf("40","50","60","70","80"), 2),
            Triple("Deret 2, 4, 8, 16, ... angka berikutnya adalah...", listOf("20","24","28","30","32"), 4),
            Triple("Sinonim 'akurat' adalah...", listOf("Samar","Tepat","Lambat","Rumit","Luas"), 1),
            Triple("Jika semua A adalah B dan semua B adalah C, maka...", listOf("Semua C adalah A","Sebagian C bukan B","Semua A adalah C","Tidak ada A yang C","A dan C berbeda"), 2),
            Triple("Rata-rata dari 10, 20, dan 30 adalah...", listOf("15","20","25","30","35"), 1),
            Triple("15% dari 200 adalah...", listOf("20","25","30","35","40"), 2),
            Triple("Deret 5, 10, 15, 20, ... adalah...", listOf("21","22","23","24","25"), 4),
            Triple("Antonim 'optimis' adalah...", listOf("Percaya diri","Pesimis","Aktif","Tekun","Realistis"), 1),
            Triple("Jika 4 pekerja menyelesaikan tugas 12 hari, dengan produktivitas sama 8 pekerja memerlukan...", listOf("3","6","8","12","24"), 1),
            Triple("2/5 dari 150 adalah...", listOf("40","50","60","70","80"), 2),
            Triple("Jika x/4 = 9, x = ...", listOf("18","27","32","36","40"), 3),
            Triple("Deret 3, 6, 12, 24, ...", listOf("36","42","48","54","60"), 2),
            Triple("Sinonim 'konkret' adalah...", listOf("Nyata","Abstrak","Samar","Maya","Rumit"), 0),
            Triple("Sebuah barang Rp80.000 mendapat diskon 25%. Harga setelah diskon...", listOf("Rp50.000","Rp55.000","Rp60.000","Rp65.000","Rp70.000"), 2),
            Triple("7 × 8 + 4 = ...", listOf("56","60","64","68","72"), 1),
            Triple("Jika 2a = 18, maka a = ...", listOf("7","8","9","10","11"), 2),
            Triple("Deret 1, 4, 9, 16, ...", listOf("20","24","25","30","36"), 2),
            Triple("Antonim 'efisien' adalah...", listOf("Hemat","Efektif","Boros","Cepat","Praktis"), 2),
            Triple("Rasio 2:3 dengan jumlah 25. Bagian pertama adalah...", listOf("8","10","12","15","18"), 1),
            Triple("45 + 36 ÷ 6 = ...", listOf("11","45","51","81","486"), 2),
            Triple("Jika 5 buku Rp75.000, harga 1 buku...", listOf("Rp10.000","Rp12.000","Rp15.000","Rp18.000","Rp20.000"), 2),
            Triple("Deret 100, 90, 80, 70, ...", listOf("50","55","60","65","75"), 2),
            Triple("Sinonim 'valid' adalah...", listOf("Sah","Salah","Lemah","Samar","Tidak pasti"), 0),
            Triple("30% dari 500 adalah...", listOf("100","120","150","180","200"), 2),
            Triple("Jika 12 + x = 31, x = ...", listOf("17","18","19","20","21"), 2),
            Triple("3³ = ...", listOf("9","18","27","36","81"), 2),
            Triple("Rata-rata 6, 8, 10, 12 adalah...", listOf("8","9","10","11","12"), 1),
            Triple("Antonim 'kompleks' adalah...", listOf("Rumit","Sederhana","Sulit","Panjang","Banyak"), 1),
            Triple("Jika 1 lusin = 12, maka 3 lusin = ...", listOf("24","30","36","42","48"), 2),
            Triple("20% dari 350 adalah...", listOf("50","60","70","80","90"), 2),
            Triple("Deret 1, 3, 6, 10, ...", listOf("12","14","15","16","18"), 2),
            Triple("Jika 9x = 81, x = ...", listOf("7","8","9","10","11"), 2)
        )
        tiuTemplates.forEachIndexed { i, t ->
            list.add(Question("TIU", t.first, t.second, t.third, "Gunakan konsep hitung/logika dasar dan periksa kembali langkah perhitungan."))
        }

        val tkpTemplates = listOf(
            "Anda menemukan rekan kerja kesulitan menyelesaikan tugas yang mendesak. Sikap terbaik adalah...",
            "Saat menerima kritik yang disampaikan dengan sopan, Anda sebaiknya...",
            "Warga meminta pelayanan sesuai prosedur tetapi antrean panjang. Anda...",
            "Anda melakukan kesalahan dalam pekerjaan. Tindakan terbaik adalah...",
            "Mendapat tugas baru yang belum pernah dikerjakan, Anda...",
            "Rekan meminta bantuan saat pekerjaan Anda sendiri juga banyak. Anda...",
            "Anda melihat data laporan kurang lengkap. Anda...",
            "Terjadi perbedaan pendapat dalam tim. Anda...",
            "Atasan memberi instruksi yang belum jelas. Anda...",
            "Anda menemukan cara kerja yang lebih efisien. Anda...",
            "Teman meminta Anda memanipulasi data untuk kepentingannya. Anda...",
            "Masyarakat menyampaikan keluhan dengan emosi. Anda...",
            "Anda terlambat menyelesaikan tugas karena kendala teknis. Anda...",
            "Ada anggota tim yang kurang aktif. Anda...",
            "Anda menerima informasi yang belum terverifikasi. Anda...",
            "Prioritas tugas berubah mendadak. Anda...",
            "Anda diminta menjaga kerahasiaan data pekerjaan. Anda...",
            "Rekan kerja mendapat pujian atas hasil kerja tim. Anda...",
            "Anda harus bekerja dengan orang yang berbeda karakter. Anda...",
            "Ada aturan baru yang mengubah cara kerja. Anda...",
            "Anda melihat fasilitas kantor digunakan tidak semestinya. Anda...",
            "Target pekerjaan tinggi dan waktu terbatas. Anda...",
            "Anda mendapat tugas yang bukan kebiasaan Anda. Anda...",
            "Terjadi konflik kecil antaranggota tim. Anda...",
            "Seorang pengguna layanan tidak memahami prosedur. Anda...",
            "Anda menemukan kesalahan pada dokumen sebelum dikirim. Anda...",
            "Rekan meminta bantuan di luar jam kerja untuk hal mendesak. Anda...",
            "Anda mendapat masukan berbeda dari dua atasan. Anda...",
            "Anda gagal mencapai target. Anda...",
            "Ada kesempatan mengikuti pelatihan. Anda...",
            "Anda melihat rekan baru kesulitan beradaptasi. Anda...",
            "Anda diminta mengambil keputusan cepat dengan data terbatas. Anda...",
            "Muncul rumor negatif tentang instansi. Anda..."
        )
        val options = listOf(
            "Membantu dan berkoordinasi",
            "Menolak agar tidak repot",
            "Mengabaikannya",
            "Menyalahkan orang tersebut",
            "Menunggu sampai masalah selesai sendiri"
        )
        tkpTemplates.forEach { text ->
            list.add(Question("TKP", text, options, 0, "Pilihan yang menunjukkan pelayanan, kerja sama, tanggung jawab, integritas, dan profesionalisme umumnya paling kuat."))
        }
        return list
    }
}
