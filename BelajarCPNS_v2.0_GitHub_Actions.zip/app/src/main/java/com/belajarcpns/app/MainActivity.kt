package com.belajarcpns.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<MaterialButton>(R.id.btnTWK).setOnClickListener { openQuiz("TWK") }
        findViewById<MaterialButton>(R.id.btnTIU).setOnClickListener { openQuiz("TIU") }
        findViewById<MaterialButton>(R.id.btnTKP).setOnClickListener { openQuiz("TKP") }
        findViewById<MaterialButton>(R.id.btnAll).setOnClickListener { openQuiz("Campuran") }
    }

    private fun openQuiz(category: String) {
        startActivity(Intent(this, QuizActivity::class.java).putExtra("category", category))
    }
}
